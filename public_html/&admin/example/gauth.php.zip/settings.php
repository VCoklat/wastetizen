<?php
require_once "../db_connect.php";
/* Google App Client Id */
define('CLIENT_ID', '847472240578-ovjoi4c5md7lqsf3dt7ooc8qggaa3ars.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'cUjYPQzlbkZLfbBq34Xip15E');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://1928.id/inasec/admin/login_check.php');

?>