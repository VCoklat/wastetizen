<?php
  include "check.php";
?>

    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php
            require_once "../db_connect.php";
            echo $nama_web;
        ?></title>

        <!--<link href="netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">-->
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Bootstrap 3.3.5 -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <!-- Theme style -->
        <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/themes/default/style.min.css" />
        <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
        <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
          <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

        <!--jquery-->
        <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
        <script type="text/javascript" src="js/ajax_kota.js"></script>
        <link rel="stylesheet" href="dist/css/summernote.css">
        <script src="dist/js/summernote.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>-->
        <style>
        select > option:checked
{
    box-shadow: 0 0 10px 100px #50ff3d inset;
}        
        
        
        
        select > option:hover
{
    box-shadow: 0 0 10px 100px #3bcaf9 inset;
}


</style>
    </head>

    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <!-- Logo -->
                <a href="#" class="logo" style="padding-left: 0px; padding-right: 0px;">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>19</b>28</span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg"><img src="../img/<?php echo $logo_kecil;?>" width="50%"></span>
                </a>
                <!-- Header Navbar: style can be found in header.less -->
                <nav class="navbar navbar-static-top" role="navigation">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        <span class="glyphicon glyphicon-menu-hamburger"></span>
                    </a>
                    <div class="navbar-custom-menu">
						<ul class="nav navbar-nav">
							<!-- User Account: style can be found in dropdown.less -->
							<li class="dropdown user user-menu" style="line-height: 90%">
								<a href="../index.php" target="_blank"style="display:block;  height:60px;">
								    
									<!--<img src="../../img/about.jpg" class="user-image" alt="User Image" style="margin-left:10px;">-->
									<i class="glyphicon glyphicon-globe" style="font-size:20px; color:black"><font style="font-family:arial; font-size:22px" ><b> Website</b></font> </i>
									<!--<span class="hidden-xs"> </span>-->
								</a>
							</li>
							<li class="dropdown user user-menu" style="line-height: 90%">
								<a href="logout.php" style="display:block;  height:60px;">
								    
									<i class="glyphicon glyphicon-log-out" style="font-size:20px; color:black"><font style="font-family:arial; font-size:22px"><b> LogOut</b></font> </i>
									<!--<span class="hidden-xs"> </span>-->
								</a>
							</li>
							<li class="dropdown user user-menu" style="line-height: 90%">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="display:block;  height:60px;">
								    
									<img src="img/user.png" class="user-image" alt="User Image" style="margin-left:10px;">
									<!--<span class="hidden-xs"> </span>-->
								</a>
								<ul class="dropdown-menu">									 
									<li class="user-header" style="background-color: #FDF9ED; line-height: 10px; height:200px">
										<img src="img/user.png" class="img-circle" alt="User Image">
										<p style="color:black;">
								    		<?php
								 			    // echo $_SESSION['username'];
								    		?>
										</p>
									<select id="dynamic_select" class="form-control">
                                            <option value="http://1928.id/INAM2C/admin">Log In as Admin</option>
                                            <option value="http://1928.id/INAM2C/jury">Log In as Jury</option>
                                            <option value="http://1928.id/INAM2C/super_jury">Log In as Super Jury</option>
                                            <option value="http://1928.id/INAM2C/user">Log In as User</option>
                                        </select>

                                        
	
									</li>	
									<li class="user-footer">
										<div class="pull-left">
											<a href="?page=password"><button class="btn btn-primary btn-flat" id='editPassword'>Edit Password</button></a>
										</div>
										<div class="pull-right">
											<a href="logout.php"><button class="btn btn-default btn-flat logout">Logout</button></a>
										</div>
									</li>
								</ul>
							</li>
						</ul>
					
					</div>
                </nav>
            </header>
            <!-- Left side column. contains the logo and sidebar -->
            <?php include'menu.php'; ?>
                <!-- Content Wrapper. Contains page content -->
                <div class="content-wrapper" style="min-height: 500px;">
                    <!-- Content Header (Page header) -->

                    <!-- Main content -->
                    <section class="content">
            <?php include 'content.php'; ?>
                    </section>
                </div>
                <!-- /.content-wrapper -->
                <footer class="main-footer">
                    <div class="pull-right hidden-xs">
                        <b>Version</b> 3.0.0
                    </div>
                    <strong>Copyright &copy; 2018<a href="">DVH&JS</a>.</strong> All rights reserved.
                </footer>
                <div class="control-sidebar-bg"></div>
        </div>
        <!-- ./wrapper -->
        <!-- Bootstrap 3.3.5 -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script>
    //         $(document).ready(function () {
    //             $('.konten').summernote({
    //                 height: 300, // set editor height
    //                 minHeight: null, // set minimum height of editor
    //                 maxHeight: null, // set maximum height of editor
    //                 focus: true, // set focus to editable area after initializing summernote
    //                 toolbar: [
    //                     ['style', ['style']],
    //                     ['font', ['bold', 'italic', 'underline', 'clear']],
    //                     ['fontname', ['fontname']],
    //                     ['color', ['color']],
    //                     ['para', ['ul', 'ol', 'paragraph']],
    //                     ['height', ['height']],
    //                     ['table', ['table']],
    //                     ['insert', ['link', 'hr']],
    //                     ['view', ['fullscreen', 'codeview']]
    //                 ],
                    
				// 	onPaste: function (e) {
    //                     var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
    //                     e.preventDefault();
    //                     setTimeout(function () {
    //                         document.execCommand('insertText', false, bufferText);
    //                     }, 10);
				// 	 }
					
					
					
    //             });
				
				
    //         });
        </script>
        <script src="plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
        <!-- <script> 
        //     $(function () {
        //         $("#example1").DataTable({
        //             "order": [[<?php //echo $order; ?>, "desc"]]
        //         });
        //     });
        </script> -->
        <script>
            //$.widget.bridge('uibutton', $.ui.button);
        </script>
        <!-- Sparkline -->
        <!--<script src="plugins/sparkline/jquery.sparkline.min.js"></script>-->
        <!-- jvectormap -->
        <!--<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>-->
        <!--<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>-->
        <!-- jQuery Knob Chart -->
        <script src="plugins/knob/jquery.knob.js"></script>
        <!-- daterangepicker -->
        <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>-->
        <!--<script src="plugins/daterangepicker/daterangepicker.js"></script>-->
        <!-- datepicker -->
        <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
        <!-- Slimscroll -->
        <!--<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>-->
        <!-- FastClick -->
        <!--<script src="plugins/fastclick/fastclick.min.js"></script>-->
        <!-- AdminLTE App -->
        <script src="dist/js/app.min.js"></script>
        <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
        <!--<script src="dist/js/pages/dashboard.js"></script>-->
        <!-- AdminLTE for demo purposes -->
        <script src="dist/js/demo.js"></script>
        <script>
            $('#tgl_agenda').datepicker({
                format: 'dd-mm-yyyy'
            })
        </script>
        <script>
$('select').hover(function(){
    var count = $(this).children().length;
    $(this).attr('size', count);
},function(){
    $(this).removeAttr('size');
});


    $(function(){
      // bind change event to select
      $('#dynamic_select').on('change', function () {
          var url = $(this).val(); // get selected value
          if (url) { // require a URL
              window.location = url; // redirect
          }
          return false;
      });
    });
    
</script>
    </body>
    </html>